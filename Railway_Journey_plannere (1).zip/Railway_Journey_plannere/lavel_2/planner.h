#ifndef PLANNER_H
#define PLANNER_H

struct Station {
    // define suitable fields here
};

struct Journey {
    // define suitable fields here
};

struct Query{
    // define suitable fields here
};

class Planner {
    // define suitable fields here
};

#endif
