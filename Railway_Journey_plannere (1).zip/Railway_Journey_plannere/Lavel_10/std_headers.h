#ifndef STD_HEADERS
#define STD_HEADERS

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <cstring>
#include <cctype>

#endif
